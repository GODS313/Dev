<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if (!installed() || !is_file(APK_FILE)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('فایل اپلیکیشن پیدا نشد.');
}

$s = settings();
$name = preg_replace('/[^A-Za-z0-9._-]/', '-', (string)($s['apk_original_name'] ?? 'Zirex-Case.apk'));
if (!str_ends_with(strtolower($name), '.apk')) $name .= '.apk';

header('Content-Type: application/vnd.android.package-archive');
header('Content-Disposition: attachment; filename="' . $name . '"');
header('Content-Length: ' . filesize(APK_FILE));
header('Cache-Control: private, no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
readfile(APK_FILE);
exit;
