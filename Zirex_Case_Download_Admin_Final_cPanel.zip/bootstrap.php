<?php
declare(strict_types=1);

define('ROOT_DIR', __DIR__);
define('DATA_DIR', ROOT_DIR . '/data');
define('SETTINGS_FILE', DATA_DIR . '/settings.json');
define('APK_DIR', ROOT_DIR . '/storage/apk');
define('LOGO_DIR', ROOT_DIR . '/storage/logos');
define('APK_FILE', APK_DIR . '/app.apk');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'samesite' => 'Strict',
        'path' => '/'
    ]);
    session_start();
}

function h(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function default_settings(): array {
    $path = DATA_DIR . '/default-settings.json';
    $data = is_file($path) ? json_decode((string)file_get_contents($path), true) : [];
    return is_array($data) ? $data : [];
}

function settings(): array {
    $default = default_settings();
    if (!is_file(SETTINGS_FILE)) return $default;
    $saved = json_decode((string)file_get_contents(SETTINGS_FILE), true);
    return is_array($saved) ? array_replace($default, $saved) : $default;
}

function save_settings(array $settings): bool {
    if (!is_dir(DATA_DIR) && !mkdir(DATA_DIR, 0750, true)) return false;
    $tmp = SETTINGS_FILE . '.tmp-' . bin2hex(random_bytes(5));
    $json = json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($json === false || file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!rename($tmp, SETTINGS_FILE)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

function local_config(): array {
    $path = ROOT_DIR . '/config.local.php';
    if (!is_file($path)) return [];
    $config = require $path;
    return is_array($config) ? $config : [];
}

function installed(): bool {
    $config = local_config();
    return !empty($config['admin_password_hash']);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['csrf'];
}

function verify_csrf(?string $token): bool {
    return is_string($token) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

function require_admin(): void {
    if (empty($_SESSION['admin_ok'])) {
        header('Location: login.php');
        exit;
    }
}

function valid_hex_color(string $value): bool {
    return (bool)preg_match('/^#[0-9A-Fa-f]{6}$/', $value);
}

function format_bytes(int $bytes): string {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 1) . ' KB';
    return $bytes . ' B';
}

function logo_url(array $s): string {
    $file = basename((string)($s['logo_file'] ?? ''));
    return $file !== '' ? 'logo.php?f=' . rawurlencode($file) : 'assets/default-logo.svg';
}
