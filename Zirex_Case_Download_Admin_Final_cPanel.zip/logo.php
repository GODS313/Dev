<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$s = settings();
$file = basename((string)($s['logo_file'] ?? ''));
if ($file === '' || basename((string)($_GET['f'] ?? '')) !== $file) {
    http_response_code(404);
    exit;
}

$path = LOGO_DIR . '/' . $file;
if (!is_file($path)) {
    http_response_code(404);
    exit;
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
$allowed = ['image/png','image/jpeg','image/webp'];
if (!in_array($mime, $allowed, true)) {
    http_response_code(403);
    exit;
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Cache-Control: public, max-age=3600');
header('X-Content-Type-Options: nosniff');
readfile($path);
