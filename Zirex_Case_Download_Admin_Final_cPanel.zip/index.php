<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if (!installed()) {
    header('Location: installer.php');
    exit;
}

$s = settings();
$accent = valid_hex_color((string)($s['accent_color'] ?? '')) ? $s['accent_color'] : '#5367ff';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="<?=h($accent)?>">
  <meta name="robots" content="noindex,nofollow">
  <title><?=h($s['page_title'])?></title>
  <style>
    :root{
      --accent:<?=h($accent)?>;
      --ink:#13203a;
      --muted:#718097;
      --line:rgba(143,163,191,.25);
      --surface:rgba(255,255,255,.88);
      --dark:#091127;
    }
    *{box-sizing:border-box}
    html,body{min-height:100%}
    body{
      margin:0;
      min-height:100vh;
      display:grid;
      place-items:center;
      padding:22px;
      font-family:Tahoma,Arial,sans-serif;
      color:var(--ink);
      overflow-x:hidden;
      background:
        radial-gradient(circle at 15% 12%,color-mix(in srgb,var(--accent) 23%,transparent),transparent 32%),
        radial-gradient(circle at 88% 88%,rgba(42,202,151,.13),transparent 32%),
        linear-gradient(145deg,#edf3ff,#f8fbff 48%,#eef5ff);
    }
    body:before,body:after{
      content:"";
      position:fixed;
      border-radius:50%;
      filter:blur(12px);
      pointer-events:none;
      opacity:.7;
    }
    body:before{
      width:230px;height:230px;
      top:-85px;right:-70px;
      background:color-mix(in srgb,var(--accent) 38%,white);
    }
    body:after{
      width:210px;height:210px;
      bottom:-95px;left:-75px;
      background:#73e1ba;
    }
    .shell{
      position:relative;
      width:min(590px,100%);
      z-index:2;
    }
    .brand{
      display:flex;
      align-items:center;
      justify-content:center;
      gap:10px;
      margin-bottom:16px;
      color:#4d5e78;
      font-size:13px;
      font-weight:800;
    }
    .brand:before,.brand:after{
      content:"";
      width:34px;
      height:1px;
      background:rgba(87,108,139,.25);
    }
    .card{
      position:relative;
      overflow:hidden;
      padding:38px 30px 28px;
      text-align:center;
      border:1px solid rgba(255,255,255,.8);
      border-radius:36px;
      background:var(--surface);
      backdrop-filter:blur(22px);
      box-shadow:
        0 36px 100px rgba(28,57,100,.18),
        inset 0 1px 0 rgba(255,255,255,.9);
    }
    .card:before{
      content:"";
      position:absolute;
      inset:0 0 auto;
      height:5px;
      background:linear-gradient(90deg,transparent,var(--accent),#32c992,transparent);
    }
    .logo-wrap{
      width:98px;
      height:98px;
      margin:0 auto 20px;
      display:grid;
      place-items:center;
      border-radius:29px;
      background:linear-gradient(145deg,#fff,#edf3ff);
      border:1px solid rgba(125,148,180,.2);
      box-shadow:0 18px 42px rgba(34,62,107,.15);
      overflow:hidden;
    }
    .logo-wrap img{
      width:100%;
      height:100%;
      object-fit:cover;
    }
    .status{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:7px 12px;
      border-radius:999px;
      color:#15805c;
      background:#e9fff6;
      font-size:12px;
      font-weight:900;
    }
    .status i{
      width:8px;
      height:8px;
      border-radius:50%;
      background:#20bf7a;
      box-shadow:0 0 0 5px rgba(32,191,122,.12);
    }
    h1{
      margin:18px auto 10px;
      font-size:clamp(25px,5.4vw,34px);
      line-height:1.55;
      letter-spacing:-.4px;
    }
    .message{
      max-width:470px;
      margin:0 auto 25px;
      color:var(--muted);
      font-size:16px;
      line-height:2;
    }
    .features{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:9px;
      margin:0 0 18px;
    }
    .feature{
      padding:11px 7px;
      border:1px solid var(--line);
      border-radius:15px;
      background:rgba(255,255,255,.62);
      color:#63728a;
      font-size:11px;
      font-weight:800;
    }
    .download{
      position:relative;
      width:100%;
      min-height:66px;
      display:flex;
      align-items:center;
      justify-content:center;
      gap:11px;
      border:0;
      border-radius:20px;
      color:#fff;
      font-size:18px;
      font-weight:900;
      text-decoration:none;
      background:
        linear-gradient(135deg,color-mix(in srgb,var(--accent) 82%,white),var(--accent));
      box-shadow:
        0 18px 38px color-mix(in srgb,var(--accent) 30%,transparent),
        inset 0 1px 0 rgba(255,255,255,.28);
      transition:transform .18s ease,box-shadow .18s ease;
      animation:pulse 2.7s ease-in-out infinite;
    }
    .download:before{
      content:"↓";
      width:31px;height:31px;
      display:grid;place-items:center;
      border-radius:10px;
      background:rgba(255,255,255,.18);
      font-size:20px;
    }
    .download:hover{
      transform:translateY(-2px);
      box-shadow:0 23px 48px color-mix(in srgb,var(--accent) 36%,transparent);
    }
    .download:active{transform:scale(.985)}
    @keyframes pulse{
      0%,100%{box-shadow:0 18px 38px color-mix(in srgb,var(--accent) 28%,transparent)}
      50%{box-shadow:0 22px 48px color-mix(in srgb,var(--accent) 42%,transparent)}
    }
    .note{
      display:flex;
      align-items:center;
      justify-content:center;
      gap:7px;
      margin-top:15px;
      color:#8a97aa;
      font-size:12px;
    }
    .note:before{content:"🛡️"}
    .foot{
      margin-top:16px;
      text-align:center;
      color:#8b98aa;
      font-size:11px;
    }
    @media(max-width:520px){
      body{padding:15px}
      .card{padding:31px 18px 23px;border-radius:29px}
      .logo-wrap{width:88px;height:88px;border-radius:25px}
      .features{gap:6px}
      .feature{font-size:10px;padding:10px 4px}
    }
  </style>
</head>
<body>
  <main class="shell">
    <div class="brand"><?=h($s['brand_name'])?></div>
    <section class="card">
      <div class="logo-wrap">
        <img src="<?=h(logo_url($s))?>" alt="لوگوی سامانه">
      </div>
      <span class="status"><i></i> ثبت موفق پرونده</span>
      <h1><?=h($s['headline'])?></h1>
      <p class="message"><?=nl2br(h($s['message']))?></p>

      <div class="features">
        <div class="feature">دانلود مستقیم</div>
        <div class="feature">نسخه اندروید</div>
        <div class="feature">دسترسی پرونده</div>
      </div>

      <a class="download" href="download.php"><?=h($s['button_text'])?></a>
      <div class="note"><?=h($s['small_note'])?></div>
    </section>
    <div class="foot">برای نصب، اجازه نصب فایل‌های دریافت‌شده را فقط در صورت اعتماد به منبع فعال کنید.</div>
  </main>
</body>
</html>
