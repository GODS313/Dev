<?php
declare(strict_types=1);
require dirname(__DIR__) . '/bootstrap.php';
require_admin();

$s = settings();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'صفحه را تازه کنید.';
    } else {
        $action = (string)($_POST['action'] ?? 'save');

        if ($action === 'save') {
            $clean = fn($v, $n) => mb_substr(trim(strip_tags((string)$v)), 0, $n, 'UTF-8');

            $s['brand_name'] = $clean($_POST['brand_name'] ?? '', 80);
            $s['page_title'] = $clean($_POST['page_title'] ?? '', 100);
            $s['headline'] = $clean($_POST['headline'] ?? '', 180);
            $s['message'] = $clean($_POST['message'] ?? '', 700);
            $s['button_text'] = $clean($_POST['button_text'] ?? '', 80);
            $s['small_note'] = $clean($_POST['small_note'] ?? '', 140);

            $accent = trim((string)($_POST['accent_color'] ?? ''));
            if (!valid_hex_color($accent)) {
                $error = 'رنگ اصلی معتبر نیست.';
            } elseif ($s['headline'] === '' || $s['button_text'] === '') {
                $error = 'عنوان اصلی و متن دکمه نباید خالی باشند.';
            } else {
                $s['accent_color'] = $accent;
                $s['updated_at'] = date(DATE_ATOM);
                if (save_settings($s)) $message = 'متن و ظاهر با موفقیت ذخیره شد.';
                else $error = 'ذخیره تنظیمات انجام نشد.';
            }
        }

        if ($action === 'upload_logo' && $error === '') {
            if (empty($_FILES['logo']['name']) || $_FILES['logo']['error'] !== UPLOAD_ERR_OK) {
                $error = 'فایل لوگو دریافت نشد.';
            } elseif ((int)$_FILES['logo']['size'] > 3 * 1024 * 1024) {
                $error = 'حجم لوگو باید کمتر از ۳ مگابایت باشد.';
            } else {
                $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['logo']['tmp_name']);
                $allowed = ['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];

                if (!isset($allowed[$mime]) || @getimagesize($_FILES['logo']['tmp_name']) === false) {
                    $error = 'فقط PNG، JPG یا WEBP معتبر پذیرفته می‌شود.';
                } else {
                    if (!is_dir(LOGO_DIR)) @mkdir(LOGO_DIR, 0750, true);
                    $newName = 'logo-' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
                    $target = LOGO_DIR . '/' . $newName;

                    if (!move_uploaded_file($_FILES['logo']['tmp_name'], $target)) {
                        $error = 'ذخیره لوگو انجام نشد.';
                    } else {
                        @chmod($target, 0640);
                        $old = basename((string)($s['logo_file'] ?? ''));
                        if ($old !== '' && is_file(LOGO_DIR . '/' . $old)) @unlink(LOGO_DIR . '/' . $old);
                        $s['logo_file'] = $newName;
                        $s['updated_at'] = date(DATE_ATOM);
                        save_settings($s);
                        $message = 'لوگوی جدید ثبت شد.';
                    }
                }
            }
        }

        if ($action === 'reset_logo' && $error === '') {
            $old = basename((string)($s['logo_file'] ?? ''));
            if ($old !== '' && is_file(LOGO_DIR . '/' . $old)) @unlink(LOGO_DIR . '/' . $old);
            $s['logo_file'] = '';
            $s['updated_at'] = date(DATE_ATOM);
            save_settings($s);
            $message = 'لوگوی پیش‌فرض فعال شد.';
        }

        if ($action === 'upload_apk' && $error === '') {
            if (empty($_FILES['apk']['name']) || $_FILES['apk']['error'] !== UPLOAD_ERR_OK) {
                $error = 'فایل APK دریافت نشد.';
            } elseif ((int)$_FILES['apk']['size'] > 120 * 1024 * 1024) {
                $error = 'حجم APK باید کمتر از ۱۲۰ مگابایت باشد.';
            } else {
                $name = (string)$_FILES['apk']['name'];
                $tmp = (string)$_FILES['apk']['tmp_name'];
                $header = file_get_contents($tmp, false, null, 0, 4);

                if (!str_ends_with(strtolower($name), '.apk') || $header !== "PK\x03\x04") {
                    $error = 'فایل انتخاب‌شده APK معتبر نیست.';
                } else {
                    if (!is_dir(APK_DIR)) @mkdir(APK_DIR, 0750, true);
                    $tempTarget = APK_DIR . '/app-upload.tmp';

                    if (!move_uploaded_file($tmp, $tempTarget)) {
                        $error = 'ذخیره APK انجام نشد.';
                    } else {
                        $valid = true;

                        if (class_exists('ZipArchive')) {
                            $zip = new ZipArchive();
                            if ($zip->open($tempTarget) !== true || $zip->locateName('AndroidManifest.xml') === false) {
                                $valid = false;
                            }
                            $zip->close();
                        }

                        if (!$valid) {
                            @unlink($tempTarget);
                            $error = 'ساختار APK معتبر نیست.';
                        } else {
                            if (is_file(APK_FILE)) @unlink(APK_FILE);
                            rename($tempTarget, APK_FILE);
                            @chmod(APK_FILE, 0640);

                            $safeName = preg_replace('/[^A-Za-z0-9._-]/', '-', basename($name));
                            $s['apk_original_name'] = $safeName ?: 'Zirex-Case.apk';
                            $s['apk_size'] = filesize(APK_FILE);
                            $s['apk_sha256'] = hash_file('sha256', APK_FILE);
                            $s['updated_at'] = date(DATE_ATOM);
                            save_settings($s);
                            $message = 'نسخه جدید APK با موفقیت جایگزین شد.';
                        }
                    }
                }
            }
        }

        $s = settings();
    }
}
$accent = valid_hex_color((string)($s['accent_color'] ?? '')) ? $s['accent_color'] : '#5367ff';
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>مدیریت سایت</title>
<style>
:root{--accent:<?=h($accent)?>;--ink:#14213a;--muted:#718097;--line:#dfe6f0;--bg:#f3f6fb}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:Tahoma,Arial;line-height:1.8}
.container{width:min(1080px,calc(100% - 28px));margin:auto}.top{position:sticky;top:0;z-index:10;background:rgba(255,255,255,.92);backdrop-filter:blur(15px);border-bottom:1px solid var(--line)}
.top-row{min-height:78px;display:flex;align-items:center;justify-content:space-between;gap:12px}.actions{display:flex;gap:8px;flex-wrap:wrap}
.btn,button{border:0;border-radius:14px;padding:12px 17px;text-decoration:none;font:inherit;font-weight:900;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}.primary{background:var(--accent);color:#fff}.soft{background:#eaf0ff;color:#4054cc}.danger{background:#fff0f0;color:#b43c3c}
main{padding:28px 0 50px}.grid{display:grid;grid-template-columns:1.25fr .75fr;gap:18px}.card{background:#fff;border:1px solid var(--line);border-radius:23px;padding:23px;box-shadow:0 14px 40px rgba(33,61,99,.06)}
h1,h2{margin-top:0}label{display:grid;gap:7px;margin:13px 0;font-weight:800}input,textarea{width:100%;padding:13px 14px;border:2px solid #e2e8f0;border-radius:13px;font:inherit;outline:none}input:focus,textarea:focus{border-color:var(--accent)}textarea{min-height:110px;resize:vertical}.upload{padding:17px;border:2px dashed #d7dfeb;border-radius:16px;background:#f9fbfe}.notice{padding:13px 15px;border-radius:14px;margin-bottom:15px}.ok{background:#eafff4;color:#176d4e}.err{background:#fff0f0;color:#a23838}.meta{font-size:13px;color:var(--muted);word-break:break-all}.logo-preview{width:92px;height:92px;border-radius:24px;overflow:hidden;border:1px solid var(--line);background:#eef3fb}.logo-preview img{width:100%;height:100%;object-fit:cover}.row{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
@media(max-width:820px){.grid{grid-template-columns:1fr}.top-row{padding:12px 0}.top-row h2{font-size:18px}}
</style></head><body>
<header class="top"><div class="container top-row"><div><b>پنل مدیریت دانلود</b><div class="meta">مدیریت متن، لوگو و APK</div></div><div class="actions"><a class="btn soft" href="../index.php" target="_blank">مشاهده سایت</a><a class="btn danger" href="logout.php">خروج</a></div></div></header>
<main class="container">
<?php if($message):?><div class="notice ok"><?=h($message)?></div><?php endif;?>
<?php if($error):?><div class="notice err"><?=h($error)?></div><?php endif;?>
<div class="grid">
<section class="card">
<h1>متن و ظاهر صفحه</h1>
<form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="save">
<label>نام برند<input name="brand_name" maxlength="80" value="<?=h($s['brand_name'])?>"></label>
<label>عنوان مرورگر<input name="page_title" maxlength="100" value="<?=h($s['page_title'])?>"></label>
<label>عنوان اصلی داخل باکس<input name="headline" maxlength="180" value="<?=h($s['headline'])?>" required></label>
<label>متن توضیحی<textarea name="message" maxlength="700"><?=h($s['message'])?></textarea></label>
<label>متن دکمه<input name="button_text" maxlength="80" value="<?=h($s['button_text'])?>" required></label>
<label>متن کوچک زیر دکمه<input name="small_note" maxlength="140" value="<?=h($s['small_note'])?>"></label>
<label>رنگ اصلی<input type="color" name="accent_color" value="<?=h($accent)?>"></label>
<button class="btn primary" style="width:100%">ذخیره تغییرات</button>
</form>
</section>

<aside class="card">
<h2>لوگوی وب‌سایت</h2>
<div class="row"><div class="logo-preview"><img src="../<?=h(logo_url($s))?>" alt=""></div><div class="meta">PNG، JPG یا WEBP<br>حداکثر ۳ مگابایت</div></div>
<form method="post" enctype="multipart/form-data" class="upload" style="margin-top:15px"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="upload_logo"><input type="file" name="logo" accept="image/png,image/jpeg,image/webp" required><button class="btn primary" style="width:100%;margin-top:10px">بارگذاری لوگو</button></form>
<form method="post" style="margin-top:9px"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="reset_logo"><button class="btn soft" style="width:100%">بازگشت به لوگوی پیش‌فرض</button></form>

<hr style="border:0;border-top:1px solid var(--line);margin:25px 0">
<h2>فایل APK</h2>
<div class="meta">نام: <?=h($s['apk_original_name'])?><br>حجم: <?=h(format_bytes((int)$s['apk_size']))?><br>SHA256:<br><?=h($s['apk_sha256'])?></div>
<form method="post" enctype="multipart/form-data" class="upload" style="margin-top:15px"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="upload_apk"><input type="file" name="apk" accept=".apk,application/vnd.android.package-archive" required><button class="btn primary" style="width:100%;margin-top:10px">جایگزینی APK</button></form>
<div class="meta" style="margin-top:12px">حداکثر حجم مجاز: ۱۲۰ مگابایت</div>
</aside>
</div>
</main></body></html>
