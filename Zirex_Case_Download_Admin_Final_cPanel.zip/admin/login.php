<?php
declare(strict_types=1);
require dirname(__DIR__) . '/bootstrap.php';

if (!installed()) {
    header('Location: ../installer.php');
    exit;
}

$error = '';
$wait = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $now = time();
    $attempts = array_values(array_filter($_SESSION['login_attempts'] ?? [], fn($t) => $t > $now - 600));

    if (count($attempts) >= 6) {
        $error = 'تعداد تلاش زیاد است. چند دقیقه بعد دوباره تلاش کنید.';
    } elseif (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'صفحه را تازه کنید.';
    } else {
        $config = local_config();
        if (password_verify((string)($_POST['password'] ?? ''), (string)($config['admin_password_hash'] ?? ''))) {
            session_regenerate_id(true);
            $_SESSION['admin_ok'] = true;
            $_SESSION['login_attempts'] = [];
            header('Location: index.php');
            exit;
        }
        $attempts[] = $now;
        $_SESSION['login_attempts'] = $attempts;
        $error = 'رمز نادرست است.';
    }
}
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ورود مدیریت</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:18px;background:linear-gradient(145deg,#09132c,#182a58);font-family:Tahoma,Arial;color:#17243c}
.card{width:min(440px,100%);padding:30px;background:#fff;border-radius:27px;box-shadow:0 30px 90px rgba(0,0,0,.28)}
h1{margin:0 0 7px}.muted{color:#718097;margin:0 0 20px}label{display:grid;gap:7px;font-weight:700}input{padding:15px;border:2px solid #e1e7ef;border-radius:14px;font:inherit}button{width:100%;min-height:55px;margin-top:15px;border:0;border-radius:15px;background:#5367ff;color:#fff;font:inherit;font-weight:900;cursor:pointer}.err{padding:12px;background:#fff0f0;color:#a23838;border-radius:13px;margin-bottom:14px}
</style></head><body><main class="card"><h1>پنل مدیریت</h1><p class="muted">مدیریت متن، لوگو و فایل اپلیکیشن</p><?php if($error):?><div class="err"><?=h($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>رمز مدیریت<input type="password" name="password" required autofocus></label><button>ورود امن</button></form></main></body></html>
