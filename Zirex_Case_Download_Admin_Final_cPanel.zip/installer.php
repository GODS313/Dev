<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

$error = '';
$done = installed();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$done) {
    if (!verify_csrf($_POST['csrf'] ?? null)) {
        $error = 'صفحه را تازه کنید و دوباره تلاش کنید.';
    } else {
        $password = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['confirm'] ?? '');

        if (strlen($password) < 8) {
            $error = 'رمز مدیریت باید حداقل ۸ کاراکتر باشد.';
        } elseif ($password !== $confirm) {
            $error = 'تکرار رمز یکسان نیست.';
        } else {
            foreach ([DATA_DIR, APK_DIR, LOGO_DIR] as $dir) {
                if (!is_dir($dir)) @mkdir($dir, 0750, true);
            }

            if (!is_file(SETTINGS_FILE)) {
                save_settings(default_settings());
            }

            $config = [
                'admin_password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'installed_at' => date(DATE_ATOM)
            ];

            $php = "<?php\nreturn " . var_export($config, true) . ";\n";
            if (file_put_contents(ROOT_DIR . '/config.local.php', $php, LOCK_EX) === false) {
                $error = 'ساخت تنظیمات انجام نشد. دسترسی پوشه را بررسی کنید.';
            } else {
                @chmod(ROOT_DIR . '/config.local.php', 0640);
                $done = true;
            }
        }
    }
}
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>نصب سامانه</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;background:#eef3fb;font-family:Tahoma,Arial;color:#17243c}
.card{width:min(540px,100%);padding:30px;background:#fff;border:1px solid #dfe6f0;border-radius:26px;box-shadow:0 25px 70px rgba(24,53,92,.13)}
h1{margin-top:0}label{display:grid;gap:7px;margin:15px 0;font-weight:700}input{padding:14px;border:2px solid #e0e6ee;border-radius:14px;font:inherit}
button,a{width:100%;min-height:54px;border:0;border-radius:15px;display:flex;align-items:center;justify-content:center;text-decoration:none;font-weight:900;font:inherit;cursor:pointer}
button{background:#5367ff;color:#fff}.links{display:grid;grid-template-columns:1fr 1fr;gap:10px}.links a{background:#edf1ff;color:#4055d8}.ok{padding:14px;background:#eafff4;color:#176d4e;border-radius:14px}.err{padding:14px;background:#fff0f0;color:#a23838;border-radius:14px}
</style></head><body><main class="card"><h1>نصب یک‌مرحله‌ای</h1>
<?php if($error):?><div class="err"><?=h($error)?></div><?php endif;?>
<?php if($done):?><div class="ok">نصب با موفقیت انجام شد ✅</div><div class="links" style="margin-top:15px"><a href="index.php">مشاهده سایت</a><a href="admin/login.php">پنل مدیریت</a></div><p>پس از تست، فایل <b>installer.php</b> را حذف یا تغییرنام بده.</p>
<?php else:?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>رمز پنل مدیریت<input type="password" name="password" minlength="8" required></label><label>تکرار رمز<input type="password" name="confirm" minlength="8" required></label><button>نصب سامانه</button></form><?php endif;?>
</main></body></html>
