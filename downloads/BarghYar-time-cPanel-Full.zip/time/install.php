<?php
declare(strict_types=1);
session_start(['cookie_httponly'=>true,'cookie_secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','cookie_samesite'=>'Strict']);
header('Cache-Control: no-store');header('X-Robots-Tag: noindex, nofollow');
require __DIR__.'/relay.php';
if(empty($_SESSION['install_csrf']))$_SESSION['install_csrf']=bin2hex(random_bytes(32));
$config=bargh_config();$message='';
if(($_SERVER['REQUEST_METHOD'] ?? '')==='POST'){
 $csrf=$_POST['csrf'] ?? ''; $secret=$_POST['secret'] ?? '';
 if(!is_string($csrf)||!hash_equals($_SESSION['install_csrf'],$csrf)){http_response_code(403);exit('درخواست نامعتبر');}
 if(empty($_SERVER['HTTPS'])||$_SERVER['HTTPS']==='off')$message='برای آزمایش اتصال، صفحه را با HTTPS باز کنید.';
 elseif(!is_string($secret)||!$config['RELAY_SECRET']||!hash_equals($config['RELAY_SECRET'],$secret))$message='کلید اتصال واردشده با تنظیمات سمت سرور یکسان نیست.';
 elseif(!empty($_SESSION['bargh_test_at'])&&time()-$_SESSION['bargh_test_at']<60)$message='برای آزمایش بعدی یک دقیقه صبر کنید.';
 else{
  $_SESSION['bargh_test_at']=time();
  $result=bargh_relay($config,'آزمایش اتصال وب‌سایت /time به ورکر و تلگرام','آزمایش مدیر');
  $messages=['delivered'=>'ارسال آزمایشی به تلگرام با موفقیت تأیید شد.','unconfigured'=>'آدرس و کلید ورکر هنوز تنظیم نشده‌اند.','invalid_url'=>'آدرس ورکر باید HTTPS و روی workers.dev باشد.','curl_missing'=>'افزونه cURL روی هاست فعال نیست.','network_failed'=>'هاست نتوانست به ورکر وصل شود.','wrong_secret'=>'کلید سایت و ورکر یکسان نیست.','relay_failed'=>'ورکر یا تلگرام ارسال را تأیید نکرد.'];
  $message=$messages[$result] ?? 'ارسال انجام نشد.';
 }
}
function h(string $s):string{return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>بررسی نصب برق‌یار</title><link rel="stylesheet" href="styles.css"><style>main{max-width:700px;margin:40px auto;padding:24px}label,input{display:block;width:100%}input{padding:12px;border:1px solid #556;border-radius:10px;background:#152139;color:white}li{padding:8px}p{margin:18px 0}button{padding:12px;border:0;border-radius:10px;background:#ddfa84;color:#16200c;margin-top:16px}</style></head><body><main><h1>بررسی نصب و اتصال برق‌یار</h1><ul><li>نسخه PHP: <?= h(PHP_VERSION) ?></li><li>cURL: <?= function_exists('curl_init')?'فعال':'غیرفعال' ?></li><li>آدرس ورکر: <?= $config['RELAY_URL']?'تنظیم شده':'تنظیم نشده' ?></li><li>کلید مشترک: <?= $config['RELAY_SECRET']?'تنظیم شده':'تنظیم نشده' ?></li></ul><p>تنظیمات قبلی از فایل خصوصی bargh-private/config.php یا متغیرهای محیطی RELAY_URL و RELAY_SECRET خوانده می‌شوند. اگر قبلاً تنظیم شده باشند، نیاز به ساخت مجدد ورکر نیست.</p><p>کلیدها را طبق راهنمای داخل بسته، در فایل خصوصی هاست و بخش Secrets ورکر قرار دهید. این صفحه کلیدها را نمایش نمی‌دهد یا تغییر نمی‌دهد.</p><?php if($message):?><p role="status"><?= h($message) ?></p><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?= h($_SESSION['install_csrf']) ?>"><label for="secret">کلید مشترک ورکر برای اجازه ارسال آزمایشی</label><input id="secret" name="secret" type="password" autocomplete="off" required><button type="submit">ارسال پیام آزمایشی به تلگرام</button></form><p><a href="./">مشاهده سایت ←</a></p></main></body></html>
