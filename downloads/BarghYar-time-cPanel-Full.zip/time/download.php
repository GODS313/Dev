<?php
declare(strict_types=1);
session_start(['cookie_httponly'=>true,'cookie_secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','cookie_samesite'=>'Strict']);
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '')!=='POST') { header('Allow: POST'); http_response_code(405); exit; }
if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['bargh_csrf']) || !hash_equals($_SESSION['bargh_csrf'],$_POST['csrf'])) { http_response_code(403); exit; }
require __DIR__.'/relay.php';
$status='duplicate';
if (empty($_SESSION['bargh_logged_at']) || time()-(int)$_SESSION['bargh_logged_at']>=60) {
 $ua=$_SERVER['HTTP_USER_AGENT'] ?? '';
 $device=preg_match('/android/i',$ua) ? 'Android' : (preg_match('/iPhone|iPad|iPod/i',$ua) ? 'iOS' : 'Web');
 $status=bargh_relay(bargh_config(),'کلیک دریافت برق من — ورود به صفحه رسمی دریافت',$device);
 if ($status==='delivered') $_SESSION['bargh_logged_at']=time();
}
error_log('bargh_download relay='.$status);
session_write_close();
header('Referrer-Policy: no-referrer');
header('Location: https://bargheman.com/mobile-app',true,303);
exit;
