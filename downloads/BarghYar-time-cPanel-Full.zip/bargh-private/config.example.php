<?php
// Rename to config.php OUTSIDE public_html. Keep an existing config.php unchanged.
return [
    'RELAY_URL' => '', // Paste the exact existing iLive Worker HTTPS URL.
    'RELAY_SECRET' => '', // Same existing RELAY_SECRET stored in that Worker.
];
