<?php
require "config.php"; $s=gs(); $f=UP."/".basename($s["apk"]);
if(!$s["apk"]||!is_file($f)){http_response_code(404);exit("APK not found");}

$payload=json_encode([
 "site"=>"iLive",
 "time"=>date("c"),
 "device"=>dev(),
 "ip"=>ip(),
 "event"=>"APK دانلود شد"
], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

if(!empty($s["relay_url"]) && !empty($s["relay_secret"])){
 $sig=hash_hmac("sha256",$payload,$s["relay_secret"]);
 $headers=["Content-Type: application/json","X-iLive-Signature: ".$sig];
 if(function_exists("curl_init")){
   $c=curl_init($s["relay_url"]);
   curl_setopt_array($c,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>$payload,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>1,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>6]);
   @curl_exec($c); @curl_close($c);
 } else {
   @file_get_contents($s["relay_url"],false,stream_context_create(["http"=>[
     "method"=>"POST","header"=>implode("\r\n",$headers)."\r\n","content"=>$payload,"timeout"=>6,"ignore_errors"=>true
   ]]));
 }
}
header("Content-Type: application/vnd.android.package-archive");
header('Content-Disposition: attachment; filename="iLive.apk"');
header("Content-Length: ".filesize($f));
readfile($f); exit;
?>