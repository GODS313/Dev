Admin: /admin/
User: admin
Password: ChangeMe123!
Set Telegram Bot Token + Chat ID, upload APK, save.