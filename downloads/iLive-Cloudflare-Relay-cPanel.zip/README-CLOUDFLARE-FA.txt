iLive Cloudflare Relay package

هدف:
هاست سایت فقط یک درخواست HTTPS امضاشده به Cloudflare Worker می‌فرستد.
Worker پیام را به Telegram Bot API می‌فرستد.
Bot Token روی هاست سایت ذخیره نمی‌شود.

Cloudflare Worker secrets:
TG_BOT_TOKEN = توکن ربات
TG_CHAT_ID = شناسه چت/گروه
RELAY_SECRET = یک رشته تصادفی طولانی (مثلاً 40+ کاراکتر)

در پنل iLive:
Cloudflare Worker URL = آدرس workers.dev
Relay Secret = دقیقاً همان RELAY_SECRET

فایل Worker: cloudflare-worker.js
