<?php
session_start();
define("SET",__DIR__."/data/settings.json"); define("UP",__DIR__."/uploads");
function ds(){return ["apk"=>"","tg_token"=>"","tg_chat"=>"","relay_url"=>"","relay_secret"=>"","user"=>"admin","pass"=>password_hash("ChangeMe123!",PASSWORD_DEFAULT)];}
function gs(){if(!file_exists(SET)){ss(ds());return ds();}$x=json_decode(file_get_contents(SET),true);return is_array($x)?array_merge(ds(),$x):ds();}
function ss($x){return file_put_contents(SET,json_encode($x,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function h($x){return htmlspecialchars((string)$x,ENT_QUOTES,"UTF-8");}
function ip(){foreach(["HTTP_CF_CONNECTING_IP","HTTP_X_FORWARDED_FOR","REMOTE_ADDR"] as $k){if(!empty($_SERVER[$k])){$v=trim(explode(",",$_SERVER[$k])[0]);if(filter_var($v,FILTER_VALIDATE_IP))return $v;}}return "Unknown";}
function dev(){$u=strtolower($_SERVER["HTTP_USER_AGENT"]??"");if(strpos($u,"android")!==false)return "Android";if(strpos($u,"iphone")!==false)return "iPhone";if(strpos($u,"windows")!==false)return "Windows";return "Other";}
function tg($t,$c,$m){if(!$t||!$c)return;$url="https://api.telegram.org/bot".$t."/sendMessage";$p=http_build_query(["chat_id"=>$c,"text"=>$m]);if(function_exists("curl_init")){$x=curl_init($url);curl_setopt_array($x,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>$p,CURLOPT_RETURNTRANSFER=>1,CURLOPT_TIMEOUT=>4]);curl_exec($x);curl_close($x);}else @file_get_contents($url,false,stream_context_create(["http"=>["method"=>"POST","header"=>"Content-Type: application/x-www-form-urlencoded\r\n","content"=>$p,"timeout"=>4]]));}
?>