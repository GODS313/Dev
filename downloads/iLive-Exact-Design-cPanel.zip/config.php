<?php
session_start();
define('ROOT',__DIR__); define('DATA',ROOT.'/data/settings.json'); define('UP',ROOT.'/uploads');
function defs(){return ['badge'=>'🔞 مخصوص بزرگسالان بالای ۱۸ سال','headline'=>'iLive','lead'=>'لایو چت زنده را با ۱۴ میلیون کاربر ایرانی شروع کنید','sub'=>'آشنایی، گفت‌وگوی زنده و لحظه‌های واقعی','s1'=>'★ ۴.۸','l1'=>'رضایت کاربران','s2'=>'۲۴/۷','l2'=>'آنلاین و زنده','s3'=>'۱۴+ میلیون','l3'=>'کاربر ایرانی','confirm'=>'☑️ تأیید می‌کنم که بالای ۱۸ سال دارم','download'=>'⬇️ دانلود اپلیکیشن','after'=>'✅ دانلود شروع شد. حالا روی فایل بزنید تا نصب شود.','apk'=>'','user'=>'admin','pass'=>password_hash('ChangeMe123!',PASSWORD_DEFAULT)];}
function loadS(){if(!file_exists(DATA)){saveS(defs());return defs();}$x=json_decode(file_get_contents(DATA),true);return is_array($x)?array_merge(defs(),$x):defs();}
function saveS($x){return file_put_contents(DATA,json_encode($x,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX)!==false;}
function e($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function tok(){if(empty($_SESSION['tok']))$_SESSION['tok']=bin2hex(random_bytes(20));return $_SESSION['tok'];}
function ok($x){return is_string($x)&&hash_equals($_SESSION['tok']??'',$x);}
?>