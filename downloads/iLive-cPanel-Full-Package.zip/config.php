<?php
declare(strict_types=1);
session_start();

define('ILIVE_ROOT', __DIR__);
define('ILIVE_DATA', ILIVE_ROOT . '/data/settings.json');
define('ILIVE_UPLOADS', ILIVE_ROOT . '/uploads');

if (!is_dir(ILIVE_UPLOADS)) @mkdir(ILIVE_UPLOADS, 0755, true);
if (!is_dir(dirname(ILIVE_DATA))) @mkdir(dirname(ILIVE_DATA), 0755, true);

function default_settings(): array {
    return [
        'site_title' => 'iLive',
        'headline' => 'iLive — تجربه‌ای ساده برای دریافت اپلیکیشن',
        'description' => 'نسخه جدید اپلیکیشن را از دکمه زیر دریافت کنید.',
        'notice' => 'این سرویس برای افراد ۱۸ سال به بالا در نظر گرفته شده است.',
        'download_label' => 'دانلود اپلیکیشن',
        'apk_file' => '',
        'hero_image' => '',
        'footer_text' => '© iLive',
        'telegram_bot_token' => '',
        'telegram_download_bot' => '',
        'adult_gate' => true,
        'admin_user' => 'admin',
        'admin_pass_hash' => password_hash('ChangeMe123!', PASSWORD_DEFAULT)
    ];
}

function load_settings(): array {
    if (!file_exists(ILIVE_DATA)) {
        $s = default_settings();
        save_settings($s);
        return $s;
    }
    $raw = file_get_contents(ILIVE_DATA);
    $data = json_decode($raw ?: '', true);
    return is_array($data) ? array_merge(default_settings(), $data) : default_settings();
}

function save_settings(array $settings): bool {
    $tmp = ILIVE_DATA . '.tmp';
    $json = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, ILIVE_DATA);
}

function e(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_check(?string $token): bool {
    return is_string($token) && hash_equals($_SESSION['csrf'] ?? '', $token);
}

function is_admin(): bool {
    return !empty($_SESSION['ilive_admin']);
}

function require_admin(): void {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}
?>