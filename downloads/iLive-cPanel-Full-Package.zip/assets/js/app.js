(() => {
  const gate = document.getElementById('ageGate');
  const accept = document.getElementById('acceptAge');
  const leave = document.getElementById('leavePage');

  if (gate && localStorage.getItem('ilive_age_ok') === '1') gate.remove();

  accept?.addEventListener('click', () => {
    localStorage.setItem('ilive_age_ok', '1');
    gate.classList.add('hide');
    setTimeout(() => gate.remove(), 260);
  });

  leave?.addEventListener('click', () => {
    location.href = 'https://www.google.com/';
  });
})();