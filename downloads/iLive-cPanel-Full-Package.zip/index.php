<?php
require __DIR__ . '/config.php';
$s = load_settings();
$apkUrl = $s['apk_file'] ? 'uploads/' . rawurlencode(basename($s['apk_file'])) : '#';
$hero = $s['hero_image'] ? 'uploads/' . rawurlencode(basename($s['hero_image'])) : '';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#080b12">
<title><?= e($s['site_title']) ?></title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php if (!empty($s['adult_gate'])): ?>
<div class="age-gate" id="ageGate">
  <div class="age-card">
    <div class="age-badge">18+</div>
    <h2>تأیید سن</h2>
    <p><?= e($s['notice']) ?></p>
    <button class="primary" id="acceptAge">۱۸ سال یا بیشتر دارم</button>
    <button class="ghost" id="leavePage">خروج</button>
  </div>
</div>
<?php endif; ?>

<main class="shell">
  <nav class="nav">
    <div class="brand"><span class="brand-dot"></span><?= e($s['site_title']) ?></div>
    <span class="secure">نسخه رسمی</span>
  </nav>

  <section class="hero">
    <div class="copy">
      <span class="eyebrow">iLive APP</span>
      <h1><?= e($s['headline']) ?></h1>
      <p><?= e($s['description']) ?></p>
      <div class="notice"><?= e($s['notice']) ?></div>

      <?php if ($s['apk_file']): ?>
        <a class="download" href="<?= e($apkUrl) ?>" download>
          <span>↓</span><?= e($s['download_label']) ?>
        </a>
      <?php else: ?>
        <button class="download disabled" disabled>فایل APK هنوز بارگذاری نشده</button>
      <?php endif; ?>

      <div class="meta">
        <span>Android APK</span>
        <span>دانلود مستقیم</span>
        <span>مدیریت‌پذیر</span>
      </div>
    </div>

    <div class="visual">
      <?php if ($hero): ?>
        <img src="<?= e($hero) ?>" alt="iLive">
      <?php else: ?>
        <div class="phone">
          <div class="phone-top"></div>
          <div class="blur-grid">
            <i></i><i></i><i></i><i></i><i></i><i></i>
          </div>
          <strong>iLive</strong>
          <small>Private • 18+</small>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <section class="features">
    <article><b>دانلود سریع</b><span>فایل APK مستقیماً از هاست شما ارائه می‌شود.</span></article>
    <article><b>پنل مدیریت</b><span>متن، تصویر و فایل دانلود را بدون ویرایش کد تغییر دهید.</span></article>
    <article><b>مناسب cPanel</b><span>PHP ساده و بدون نیاز به دیتابیس.</span></article>
  </section>

  <footer><?= e($s['footer_text']) ?></footer>
</main>
<script src="assets/js/app.js"></script>
</body>
</html>