iLive - Full cPanel Package

نصب:
1) فایل ZIP را در File Manager سی‌پنل داخل public_html آپلود کنید.
2) Extract را بزنید.
3) محتویات پوشه iLive-cPanel-Full-Package را در public_html قرار دهید.
4) آدرس سایت را باز کنید.
5) برای مدیریت وارد /admin/ شوید.

ورود اولیه:
Username: admin
Password: ChangeMe123!

مهم:
- بلافاصله بعد از ورود رمز را تغییر دهید.
- PHP 8.0 یا بالاتر پیشنهاد می‌شود.
- پوشه‌های data و uploads باید قابل نوشتن باشند (معمولاً 755 کافی است؛ در بعضی هاست‌ها 775).
- حداکثر حجم آپلود APK به تنظیمات PHP هاست هم وابسته است. در صورت نیاز upload_max_filesize و post_max_size را در cPanel افزایش دهید.
- این پروژه دیتابیس نیاز ندارد.
- تنظیمات داخل data/settings.json ذخیره می‌شوند و با .htaccess از دسترسی مستقیم محافظت می‌شوند.
