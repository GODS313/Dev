<?php
require dirname(__DIR__) . '/config.php';
$s = load_settings();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $error = 'درخواست نامعتبر است.';
    } else {
        $user = trim((string)($_POST['username'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');
        if (hash_equals((string)$s['admin_user'], $user) && password_verify($pass, (string)$s['admin_pass_hash'])) {
            session_regenerate_id(true);
            $_SESSION['ilive_admin'] = true;
            header('Location: index.php');
            exit;
        }
        $error = 'نام کاربری یا رمز عبور اشتباه است.';
    }
}
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ورود مدیریت iLive</title><link rel="stylesheet" href="../assets/css/admin.css">
</head><body>
<div class="login-wrap"><form class="panel login" method="post">
<h1>مدیریت iLive</h1><p>برای ورود اطلاعات مدیر را وارد کنید.</p>
<?php if ($error): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<label>نام کاربری<input name="username" required autocomplete="username"></label>
<label>رمز عبور<input type="password" name="password" required autocomplete="current-password"></label>
<button>ورود</button>
<a href="../index.php">بازگشت به سایت</a>
</form></div></body></html>