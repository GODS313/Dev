<?php
require dirname(__DIR__) . '/config.php';
require_admin();
$s = load_settings();
$msg = '';
$err = '';

function upload_file(string $field, array $allowedExt, int $maxSize): ?string {
    if (empty($_FILES[$field]['name'])) return null;
    if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('خطا در بارگذاری فایل.');
    if ($_FILES[$field]['size'] > $maxSize) throw new RuntimeException('حجم فایل بیشتر از حد مجاز است.');
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) throw new RuntimeException('پسوند فایل مجاز نیست.');
    $name = $field . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
    $dest = ILIVE_UPLOADS . '/' . $name;
    if (!move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) throw new RuntimeException('ذخیره فایل ناموفق بود.');
    return $name;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? null)) {
        $err = 'درخواست نامعتبر است.';
    } else {
        try {
            $s['site_title'] = trim((string)($_POST['site_title'] ?? $s['site_title']));
            $s['headline'] = trim((string)($_POST['headline'] ?? $s['headline']));
            $s['description'] = trim((string)($_POST['description'] ?? $s['description']));
            $s['notice'] = trim((string)($_POST['notice'] ?? $s['notice']));
            $s['download_label'] = trim((string)($_POST['download_label'] ?? $s['download_label']));
            $s['footer_text'] = trim((string)($_POST['footer_text'] ?? $s['footer_text']));
            $s['telegram_bot_token'] = trim((string)($_POST['telegram_bot_token'] ?? ''));
            $s['telegram_download_bot'] = trim((string)($_POST['telegram_download_bot'] ?? ''));
            $s['adult_gate'] = isset($_POST['adult_gate']);

            $apk = upload_file('apk_file', ['apk'], 200 * 1024 * 1024);
            if ($apk) $s['apk_file'] = $apk;
            $hero = upload_file('hero_image', ['jpg','jpeg','png','webp'], 8 * 1024 * 1024);
            if ($hero) $s['hero_image'] = $hero;

            if (!empty($_POST['new_password'])) {
                if (strlen((string)$_POST['new_password']) < 10) {
                    throw new RuntimeException('رمز جدید باید حداقل ۱۰ کاراکتر باشد.');
                }
                $s['admin_pass_hash'] = password_hash((string)$_POST['new_password'], PASSWORD_DEFAULT);
            }
            if (!empty($_POST['admin_user'])) $s['admin_user'] = trim((string)$_POST['admin_user']);

            if (!save_settings($s)) throw new RuntimeException('ذخیره تنظیمات ناموفق بود.');
            $msg = 'تنظیمات ذخیره شد.';
        } catch (Throwable $e) {
            $err = $e->getMessage();
        }
    }
}
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>پنل مدیریت iLive</title><link rel="stylesheet" href="../assets/css/admin.css">
</head><body>
<header class="top"><b>iLive Admin</b><div><a href="../index.php" target="_blank">مشاهده سایت</a><a href="logout.php">خروج</a></div></header>
<main class="admin-shell">
<?php if ($msg): ?><div class="success"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="error"><?= e($err) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="grid">
<input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

<section class="panel"><h2>محتوای سایت</h2>
<label>نام سایت<input name="site_title" value="<?= e($s['site_title']) ?>"></label>
<label>تیتر اصلی<input name="headline" value="<?= e($s['headline']) ?>"></label>
<label>توضیحات<textarea name="description"><?= e($s['description']) ?></textarea></label>
<label>پیام هشدار<textarea name="notice"><?= e($s['notice']) ?></textarea></label>
<label>متن دکمه دانلود<input name="download_label" value="<?= e($s['download_label']) ?>"></label>
<label>متن فوتر<input name="footer_text" value="<?= e($s['footer_text']) ?>"></label>
<label class="check"><input type="checkbox" name="adult_gate" <?= !empty($s['adult_gate'])?'checked':'' ?>> نمایش تأیید سن 18+</label>
</section>

<section class="panel"><h2>فایل و تصویر</h2>
<label>فایل APK<input type="file" name="apk_file" accept=".apk"></label>
<small>فعلی: <?= e($s['apk_file'] ?: 'ثبت نشده') ?></small>
<label>تصویر اصلی<input type="file" name="hero_image" accept=".jpg,.jpeg,.png,.webp"></label>
<small>فعلی: <?= e($s['hero_image'] ?: 'ثبت نشده') ?></small>
<h2>تنظیمات تلگرام</h2>
<label>توکن ربات<input type="password" name="telegram_bot_token" value="<?= e($s['telegram_bot_token']) ?>" autocomplete="off"></label>
<label>آدرس/نام ربات دانلود<input name="telegram_download_bot" value="<?= e($s['telegram_download_bot']) ?>"></label>
</section>

<section class="panel"><h2>امنیت مدیریت</h2>
<label>نام کاربری مدیر<input name="admin_user" value="<?= e($s['admin_user']) ?>"></label>
<label>رمز عبور جدید<input type="password" name="new_password" placeholder="حداقل ۱۰ کاراکتر"></label>
<p class="hint">بعد از اولین ورود، رمز پیش‌فرض را حتماً تغییر دهید.</p>
<button class="save">ذخیره همه تغییرات</button>
</section>
</form>
</main></body></html>