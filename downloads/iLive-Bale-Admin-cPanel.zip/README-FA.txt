iLive Full Admin + Bale Logs

پنل مدیریت: /admin/
Username: admin
Password: ChangeMe123!

امکانات:
- تغییر همه متن‌ها
- تغییر لوگو
- تغییر و آپلود APK
- تنظیم Bot Token بله
- تنظیم چند Chat ID از پنل
- تغییر قالب پیام لاگ
- فعال/غیرفعال کردن لاگ دانلود
- تست ارسال به بله
- ثبت زمان، دستگاه و IP عمومی درخواست در پیام دانلود

Endpoint بله: https://tapi.bale.ai/bot<TOKEN>/sendMessage
