<?php
session_start();
define('DATA',__DIR__.'/data/settings.json');
define('UP',__DIR__.'/uploads');
function defaults(){return [
'badge'=>'🔞 مخصوص بزرگسالان بالای ۱۸ سال','title'=>'iLive','lead'=>'لایو چت زنده را با ۱۴ میلیون کاربر ایرانی شروع کنید','sub'=>'آشنایی، گفت‌وگوی زنده و لحظه‌های واقعی',
's1'=>'★ ۴.۸','l1'=>'رضایت کاربران','s2'=>'۲۴/۷','l2'=>'آنلاین و زنده','s3'=>'۱۴+ میلیون','l3'=>'کاربر ایرانی',
'confirm'=>'تأیید می‌کنم که بالای ۱۸ سال دارم','button'=>'⬇️ دانلود اپلیکیشن','after'=>'✅ دانلود شروع شد. حالا روی فایل بزنید تا نصب شود.','footer'=>'© iLive',
'logo'=>'','apk'=>'','bale_enabled'=>false,'bale_token'=>'','bale_chat_ids'=>'','bale_template'=>"🐸 | دانلود جدید\n\n🌐 سایت: {site}\n🕒 زمان: {time}\n📱 دستگاه: {device}\n🌐 IP: {ip}\n📥 {event}",
'user'=>'admin','hash'=>password_hash('ChangeMe123!',PASSWORD_DEFAULT)
];}
function loadS(){if(!file_exists(DATA)){saveS(defaults());return defaults();}$x=json_decode(@file_get_contents(DATA),true);return is_array($x)?array_merge(defaults(),$x):defaults();}
function saveS($x){return file_put_contents(DATA,json_encode($x,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)!==false;}
function e($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function token(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function valid($x){return is_string($x)&&hash_equals($_SESSION['csrf']??'',$x);}
function clientIp(){if(!empty($_SERVER['HTTP_CF_CONNECTING_IP'])&&filter_var($_SERVER['HTTP_CF_CONNECTING_IP'],FILTER_VALIDATE_IP))return $_SERVER['HTTP_CF_CONNECTING_IP'];$x=$_SERVER['REMOTE_ADDR']??'Unknown';return filter_var($x,FILTER_VALIDATE_IP)?$x:'Unknown';}
function deviceName(){$u=strtolower($_SERVER['HTTP_USER_AGENT']??'');if(strpos($u,'android')!==false)return 'Android';if(strpos($u,'iphone')!==false)return 'iPhone';if(strpos($u,'ipad')!==false)return 'iPad';if(strpos($u,'windows')!==false)return 'Windows';if(strpos($u,'macintosh')!==false)return 'Mac';return 'Other';}
function chatIds($raw){$a=preg_split('/[\s,;]+/',trim((string)$raw));$o=[];foreach($a?:[] as $id){$id=trim($id);if($id!=='')$o[]=$id;}return array_values(array_unique($o));}
function baleText($s,$event){return strtr((string)$s['bale_template'],['{site}'=>(string)$s['title'],'{time}'=>date('Y-m-d H:i:s'),'{device}'=>deviceName(),'{ip}'=>clientIp(),'{event}'=>$event]);}
function baleSendOne($token,$chat,$text){$url='https://tapi.bale.ai/bot'.rawurlencode((string)$token).'/sendMessage';$body=json_encode(['chat_id'=>(string)$chat,'text'=>(string)$text],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(function_exists('curl_init')){$c=curl_init($url);curl_setopt_array($c,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>8,CURLOPT_SSL_VERIFYPEER=>true]);$r=curl_exec($c);$err=curl_error($c);$code=(int)curl_getinfo($c,CURLINFO_HTTP_CODE);curl_close($c);if($r===false)return ['ok'=>false,'error'=>$err?:'connection failed','code'=>$code];$j=json_decode($r,true);return ['ok'=>!empty($j['ok']),'error'=>$j['description']??'','code'=>$code];}$ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/json\r\n",'content'=>$body,'timeout'=>8,'ignore_errors'=>true]]);$r=@file_get_contents($url,false,$ctx);if($r===false)return ['ok'=>false,'error'=>'HTTP request failed'];$j=json_decode($r,true);return ['ok'=>!empty($j['ok']),'error'=>$j['description']??''];}
function baleSendAll($s,$event){if(empty($s['bale_enabled']))return ['sent'=>0,'failed'=>0,'results'=>[]];$ids=chatIds($s['bale_chat_ids']);$text=baleText($s,$event);$sent=0;$failed=0;$res=[];foreach($ids as $id){$r=baleSendOne($s['bale_token'],$id,$text);$res[$id]=$r;if(!empty($r['ok']))$sent++;else$failed++;}return ['sent'=>$sent,'failed'=>$failed,'results'=>$res];}
?>
