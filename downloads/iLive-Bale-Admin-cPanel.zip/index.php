<?php require __DIR__.'/config.php';$s=loadS();$hasApk=$s['apk']&&is_file(UP.'/'.basename($s['apk']));$logo=$s['logo']?'uploads/'.rawurlencode(basename($s['logo'])):'';?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><title><?=e($s['title'])?></title><link rel="stylesheet" href="assets/style.css?v=9"><style>.custom-logo{width:190px;height:190px;margin:54px auto 50px;display:flex;align-items:center;justify-content:center}.custom-logo img{max-width:100%;max-height:100%;object-fit:contain;border-radius:30px}footer{margin-top:40px;color:#806984;font-size:12px}</style></head><body><div class="screen"><div class="panel">
<div class="badge"><?=e($s['badge'])?></div>
<?php if($logo):?><div class="custom-logo"><img src="<?=e($logo)?>" alt="logo"></div><?php else:?><div class="app-logo"><div class="play">▶</div><span></span></div><?php endif;?>
<h1><?=e($s['title'])?></h1><p class="lead"><?=e($s['lead'])?></p><p class="sub"><?=e($s['sub'])?></p>
<div class="stats"><div class="stat"><b><?=e($s['s1'])?></b><small><?=e($s['l1'])?></small></div><div class="stat"><b><?=e($s['s2'])?></b><small><?=e($s['l2'])?></small></div><div class="stat"><b><?=e($s['s3'])?></b><small><?=e($s['l3'])?></small></div></div>
<label class="age"><input id="age" type="checkbox"><i></i><span><?=e($s['confirm'])?></span></label>
<?php if($hasApk):?><a id="download" class="download disabled" href="download.php"><?=e($s['button'])?></a><p id="done" class="done hidden"><?=e($s['after'])?></p><?php else:?><div class="download disabled">⬇️ فایل APK هنوز از پنل بارگذاری نشده</div><?php endif;?><footer><?=e($s['footer'])?></footer>
</div></div><script src="assets/app.js?v=9"></script></body></html>
