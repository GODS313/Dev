<?php
declare(strict_types=1);
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS']==='off') { http_response_code(403); exit('پنل را با https باز کنید.'); }
ini_set('session.use_strict_mode','1');
session_name('adlisho_admin');session_start(['cookie_httponly'=>true,'cookie_secure'=>true,'cookie_samesite'=>'Strict']);
header('Cache-Control: no-store');header('X-Frame-Options: DENY');header('X-Content-Type-Options: nosniff');header('Referrer-Policy: no-referrer');
$dir=dirname(__DIR__).'/adlisho-private';$file=$dir.'/config.php';
if(!is_file($file)){http_response_code(503);exit('ابتدا نصب اصلی سایت را تکمیل کنید.');}
$c=require $file;if(!is_array($c))exit('تنظیمات معتبر نیست.');
function esc($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function save_config($file,$c){$tmp=tempnam(dirname($file),'cfg');if(!$tmp)throw new Exception('ذخیره ممکن نیست.');chmod($tmp,0600);$data="<?php\nreturn ".var_export($c,true).";\n";if(file_put_contents($tmp,$data,LOCK_EX)!==strlen($data)||!rename($tmp,$file)){@unlink($tmp);throw new Exception('ذخیره ناموفق بود.');}if(function_exists('opcache_invalidate'))opcache_invalidate($file,true);}
if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));
$auth=!empty($c['ADMIN_HASH'])&&!empty($_SESSION['auth'])&&hash_equals(hash('sha256',$c['ADMIN_HASH']),$_SESSION['auth'])&&time()-($_SESSION['last']??0)<1800;
if($auth)$_SESSION['last']=time();
$message='';$ok=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
 if(!is_string($_POST['csrf']??null)||!hash_equals($_SESSION['csrf'],$_POST['csrf']))throw new Exception('صفحه را تازه کنید.');
 $action=$_POST['action']??'';
 $lock=fopen($dir.'/admin-write.lock','c');if(!$lock||!flock($lock,LOCK_EX))throw new Exception('دوباره تلاش کنید.');
 $c=require $file;
 if($action==='login'||$action==='setup'){
  $rateFile=$dir.'/admin-rate.json';$rate=is_file($rateFile)?json_decode(file_get_contents($rateFile),true):[];
  if(!is_array($rate))$rate=[];
  $id=hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',$c['RELAY_SECRET']);
  foreach($rate as $key=>$r)if(($r['until']??0)<time())unset($rate[$key]);
  $r=$rate[$id]??['count'=>0,'until'=>time()+900];
  if($r['count']>=8)throw new Exception('تلاش بیش از حد؛ ۱۵ دقیقه بعد امتحان کنید.');
  $valid=$action==='setup' ? empty($c['ADMIN_HASH'])&&is_string($_POST['setup_key']??null)&&hash_equals($c['RELAY_SECRET'],trim($_POST['setup_key'])) : !empty($c['ADMIN_HASH'])&&password_verify((string)($_POST['password']??''),$c['ADMIN_HASH']);
  if(!$valid){$r['count']++;$rate[$id]=$r;file_put_contents($rateFile,json_encode($rate),LOCK_EX);throw new Exception('اطلاعات ورود صحیح نیست.');}
  if($action==='setup'){
   $password=(string)($_POST['password']??'');if(strlen($password)<12)throw new Exception('رمز مدیریت حداقل ۱۲ کاراکتر باشد.');
   $c['ADMIN_HASH']=password_hash($password,PASSWORD_DEFAULT);save_config($file,$c);
  }
  unset($rate[$id]);file_put_contents($rateFile,json_encode($rate),LOCK_EX);
  session_regenerate_id(true);$_SESSION['auth']=hash('sha256',$c['ADMIN_HASH']);$_SESSION['last']=time();$auth=true;$message='وارد شدید.';$ok=true;
 }elseif($auth&&hash_equals(hash('sha256',$c['ADMIN_HASH']),$_SESSION['auth'])){
  if($action==='logout'){$_SESSION=[];session_destroy();$auth=false;}
  elseif($action==='save'){
   $url=trim((string)($_POST['relay_url']??''));
   if($url!==''&&!preg_match('~^https://[a-z0-9][a-z0-9.-]*\.workers\.dev/?$~i',$url))throw new Exception('آدرس HTTPS ورکر با پسوند workers.dev لازم است.');
   $token=trim((string)($_POST['bot_token']??''));if($token!==''&&!preg_match('/^[0-9]{5,20}:[A-Za-z0-9_-]{20,100}$/',$token))throw new Exception('قالب توکن ربات معتبر نیست.');
   $chat=trim((string)($_POST['chat_id']??''));if($chat!==''&&!preg_match('/^(?:-?[0-9]{1,20}|@[A-Za-z0-9_]{5,32})$/',$chat))throw new Exception('چت‌آیدی معتبر نیست.');
   $c['RELAY_URL']=$url;$c['TG_CHAT_ID']=$chat;if($token!=='')$c['TG_BOT_TOKEN']=$token;
   $new=(string)($_POST['new_password']??'');if($new!==''){if(strlen($new)<12)throw new Exception('رمز جدید حداقل ۱۲ کاراکتر باشد.');$c['ADMIN_HASH']=password_hash($new,PASSWORD_DEFAULT);}
   save_config($file,$c);$_SESSION['auth']=hash('sha256',$c['ADMIN_HASH']);$message='تنظیمات ذخیره شد.';$ok=true;
  }elseif($action==='upload_apk'){
   $f=$_FILES['apk']??null;
   if(!$f||($f['error']??1)!==UPLOAD_ERR_OK)throw new Exception('آپلود کامل نشد؛ upload_max_filesize و post_max_size هاست را بررسی کنید.');
   if(strtolower(pathinfo($f['name'],PATHINFO_EXTENSION))!=='apk'||!is_uploaded_file($f['tmp_name']))throw new Exception('فقط فایل APK پذیرفته می‌شود.');
   $size=filesize($f['tmp_name']);if(!$size||$size>30*1024*1024)throw new Exception('حجم فایل باید حداکثر ۳۰ مگابایت باشد.');
   if(!class_exists('ZipArchive'))throw new Exception('افزونه PHP zip را در cPanel فعال کنید.');
   $zip=new ZipArchive();if($zip->open($f['tmp_name'])!==true)throw new Exception('ساختار APK معتبر نیست.');
   $valid=$zip->locateName('AndroidManifest.xml')!==false;$zip->close();
   if(!$valid)throw new Exception('فایل AndroidManifest.xml در APK موجود نیست.');
   $tmp=$dir.'/app-'.bin2hex(random_bytes(12)).'.apk';
   if(!move_uploaded_file($f['tmp_name'],$tmp))throw new Exception('ذخیره فایل ناموفق بود.');
   chmod($tmp,0600);
   if(!rename($tmp,$dir.'/application.apk')){@unlink($tmp);throw new Exception('جایگزینی فایل ناموفق بود.');}
   $message='APK آپلود شد و دکمه دانلود سایت به آن متصل است.';$ok=true;
  }elseif($action==='delete_apk'){
   if(is_file($dir.'/application.apk')&&!unlink($dir.'/application.apk'))throw new Exception('حذف فایل ممکن نیست.');
   $message='فایل حذف شد؛ دکمه به صفحه رسمی برق من برمی‌گردد.';$ok=true;
  }elseif($action==='test'){
   require_once __DIR__.'/relay.php';$result=bargh_relay(bargh_config(),'پیام آزمایشی از پنل مدیریت','Admin');
   $ok=$result==='delivered';$message=$ok?'تلگرام دریافت پیام را تأیید کرد.':'ارسال تأیید نشد: '.$result;
  }
 }else throw new Exception('دوباره وارد شوید.');
 }catch(Throwable $e){$message=$e->getMessage();}
 finally{if(isset($lock)&&is_resource($lock)){flock($lock,LOCK_UN);fclose($lock);}}
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>مدیریت عدلی‌شو</title><style>@font-face{font-family:v;src:url(vazirmatn.woff2)}*{box-sizing:border-box}body{background:#071b27;color:#eaf8ff;font:15px/1.9 v,Tahoma;margin:0;padding:24px}main{max-width:680px;margin:30px auto;background:#102c3b;border:1px solid #345564;padding:28px;border-radius:24px}h1{margin:0;font-size:28px}label{display:block;margin:17px 0 5px}input{width:100%;padding:13px;border:1px solid #52717e;background:#071b27;border-radius:10px;color:white;font:inherit;direction:ltr}button{background:#96efd0;color:#08271e;padding:12px 22px;border:0;border-radius:12px;font:inherit;cursor:pointer;margin-top:20px}small,p{color:#b9ccd5}code{overflow-wrap:anywhere;direction:ltr}a{color:#96efd0}.notice{padding:12px;border-radius:10px;background:<?= $ok?'#174737':'#592c38' ?>}details{margin-top:24px}summary{cursor:pointer}</style></head><body><main><small>ADLISHO · مدیریت اتصال</small><h1>تنظیمات ربات</h1><?php if($message):?><p class="notice"><?=esc($message)?></p><?php endif;?>
<?php if(!$auth):?><form method="post"><input type="hidden" name="csrf" value="<?=esc($_SESSION['csrf'])?>"><input type="hidden" name="action" value="<?=empty($c['ADMIN_HASH'])?'setup':'login'?>">
<?php if(empty($c['ADMIN_HASH'])):?><p>برای فعال‌سازی فقط یک‌بار، مقدار RELAY_SECRET را از فایل <code>adlisho-private/config.php</code> کنار public_html در File Manager بردار و اینجا وارد کن. نیازی به ورود به Cloudflare نیست.</p><label>کد فعال‌سازی مالک</label><input name="setup_key" type="password" required autocomplete="off"><label>رمز جدید مدیریت (حداقل ۱۲ کاراکتر)</label><?php else:?><label>رمز مدیریت</label><?php endif;?>
<input name="password" type="password" required autocomplete="<?=empty($c['ADMIN_HASH'])?'new-password':'current-password'?>"><button><?=empty($c['ADMIN_HASH'])?'فعال‌سازی پنل':'ورود'?></button></form>
<?php else:?><form method="post"><input type="hidden" name="csrf" value="<?=esc($_SESSION['csrf'])?>"><input type="hidden" name="action" value="save"><label>آدرس ورکر</label><input name="relay_url" value="<?=esc($c['RELAY_URL']??'')?>" placeholder="https://your-worker.workers.dev"><label>توکن جدید ربات</label><input name="bot_token" type="password" autocomplete="new-password" placeholder="<?=empty($c['TG_BOT_TOKEN'])?'توکن را وارد کنید':'توکن ذخیره شده؛ خالی بماند تغییر نمی‌کند'?>"><label>چت‌آیدی مقصد</label><input name="chat_id" value="<?=esc($c['TG_CHAT_ID']??'')?>"><label>رمز جدید مدیریت — اختیاری</label><input name="new_password" type="password" autocomplete="new-password"><button>ذخیره تنظیمات</button></form><form method="post"><input type="hidden" name="csrf" value="<?=esc($_SESSION['csrf'])?>"><button name="action" value="test">ارسال پیام آزمایشی با تنظیمات ذخیره‌شده</button> <button name="action" value="logout">خروج</button></form><hr><h2>فایل اپلیکیشن</h2><p>حداکثر ۳۰ مگابایت. پس از آپلود، باکس دانلود فایل را به‌عنوان اپلیکیشن ارائه‌شده توسط مدیر سایت معرفی می‌کند.</p><?php if(is_file($dir.'/application.apk')):?><p>فایل فعلی: application.apk · <?=esc(round(filesize($dir.'/application.apk')/1048576,2))?> MB</p><?php else:?><p>هنوز APK آپلود نشده است.</p><?php endif;?><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=esc($_SESSION['csrf'])?>"><input type="hidden" name="action" value="upload_apk"><input type="hidden" name="MAX_FILE_SIZE" value="31457280"><label>انتخاب APK</label><input type="file" name="apk" accept=".apk" required><button>آپلود و فعال‌کردن دانلود</button></form><form method="post"><input type="hidden" name="csrf" value="<?=esc($_SESSION['csrf'])?>"><button name="action" value="delete_apk">حذف APK فعلی</button></form><p>محدودیت فعلی هاست: upload_max_filesize = <?=esc(ini_get('upload_max_filesize'))?> · post_max_size = <?=esc(ini_get('post_max_size'))?>. برای ۳۰ مگابایت، هر دو را حداقل 40M تنظیم کنید.</p><details><summary>راه‌اندازی اولیه ورکر</summary><p>فایل worker-panel.mjs بسته را یک‌بار منتشر کن و RELAY_SECRET زیر را در Secret ورکر قرار بده. از آن به بعد توکن و چت‌آیدی فقط از همین پنل خوانده می‌شوند.</p><code><?=esc($c['RELAY_SECRET'])?></code><p>این سکرت را عمومی نکن. تغییر آن نیازمند هماهنگ‌کردن ورکر و هاست است.</p></details><p><a href="./index.php">بازگشت به سایت</a></p><?php endif;?></main></body></html>
