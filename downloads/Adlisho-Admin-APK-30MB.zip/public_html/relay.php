<?php
declare(strict_types=1);
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) { http_response_code(404); exit; }
function bargh_config(): array {
 $path=dirname(__DIR__).'/adlisho-private/config.php';
 $config=is_file($path) ? require $path : [];
 if (!is_array($config)) $config=[];
 return ['RELAY_URL'=>(string)($config['RELAY_URL'] ?? (getenv('RELAY_URL') ?: '')), 'TG_BOT_TOKEN'=>(string)($config['TG_BOT_TOKEN'] ?? ''), 'TG_CHAT_ID'=>(string)($config['TG_CHAT_ID'] ?? ''), 'RELAY_SECRET'=>(string)($config['RELAY_SECRET'] ?? (getenv('RELAY_SECRET') ?: ''))];
}
function bargh_relay(array $config, string $event, string $device): string {
 $url=$config['RELAY_URL']; $secret=$config['RELAY_SECRET'];
 if (!$url || !$secret) return 'unconfigured';
 $parts=parse_url($url);
 if (!$parts || ($parts['scheme'] ?? '')!=='https' || !preg_match('/\.workers\.dev$/i',$parts['host'] ?? '') || !empty($parts['user']) || !empty($parts['pass']) || (!empty($parts['port']) && $parts['port']!==443)) return 'invalid_url';
 if (!function_exists('curl_init')) return 'curl_missing';
 $body=json_encode(['site'=>'برق‌یار — adlisho.online','time'=>gmdate('c'),'device'=>$device,'ip'=>'ثبت نمی‌شود','event'=>$event,'bot_token'=>$config['TG_BOT_TOKEN'] ?? '', 'chat_id'=>$config['TG_CHAT_ID'] ?? ''],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
 if ($body===false) return 'encoding_failed';
 $ch=curl_init($url);
 curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-iLive-Signature: '.hash_hmac('sha256',$body,$secret)],CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>12,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
 $response=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
 if ($response===false) return 'network_failed';
 $data=json_decode($response,true);
 if ($code===401) return 'wrong_secret';
 return $code>=200 && $code<300 && is_array($data) && ($data['ok'] ?? false)===true ? 'delivered' : 'relay_failed';
}
