<?php
declare(strict_types=1);
session_start(['cookie_httponly'=>true,'cookie_secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','cookie_samesite'=>'Strict']);
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '')!=='POST') { header('Allow: POST'); http_response_code(405); exit; }
if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['bargh_csrf']) || !hash_equals($_SESSION['bargh_csrf'],$_POST['csrf'])) { http_response_code(403); exit; }
require __DIR__.'/relay.php';
$apk=dirname(__DIR__).'/adlisho-private/application.apk';
$hasApk=is_file($apk);
$status='duplicate';
if (empty($_SESSION['bargh_logged_at']) || time()-(int)$_SESSION['bargh_logged_at']>=60) {
 $ua=$_SERVER['HTTP_USER_AGENT'] ?? '';
 $device=preg_match('/android/i',$ua) ? 'Android' : (preg_match('/iPhone|iPad|iPod/i',$ua) ? 'iOS' : 'Web');
  $logPath=dirname(__DIR__).'/adlisho-private/clicks.log';
 if (is_dir(dirname($logPath))) {
  if (is_file($logPath) && filesize($logPath)>2097152) @rename($logPath,$logPath.'.previous');
  file_put_contents($logPath,json_encode(['time'=>gmdate('c'),'event'=>'download_click','device'=>$device]).PHP_EOL,FILE_APPEND|LOCK_EX);
 }
 $_SESSION['bargh_logged_at']=time();
 $status=bargh_relay(bargh_config(),($hasApk?'کلیک دریافت APK ارائه‌شده توسط مدیر سایت':'کلیک دریافت برق من — ورود به صفحه رسمی دریافت'),$device);
 if ($status==='delivered') $_SESSION['bargh_logged_at']=time();
}
error_log('bargh_download relay='.$status);
session_write_close();
header('Referrer-Policy: no-referrer');
if($hasApk){
 $fp=fopen($apk,'rb');if(!$fp){http_response_code(404);exit;}
 header('Content-Type: application/vnd.android.package-archive');
 header('Content-Disposition: attachment; filename="application.apk"');
 header('X-Content-Type-Options: nosniff');header('Content-Length: '.fstat($fp)['size']);
 fpassthru($fp);fclose($fp);exit;
}
header('Location: https://bargheman.com/mobile-app',true,303);
exit;
