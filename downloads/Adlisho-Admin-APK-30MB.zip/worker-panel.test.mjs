import worker from './worker-panel.mjs';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
const secret='test-secret-only';let calls=[];
globalThis.fetch=async(url,options)=>{calls.push({url,body:JSON.parse(options.body)});return Response.json({ok:true});};
async function request(data,signature){const body=JSON.stringify(data);return worker.fetch(new Request('https://example.workers.dev',{method:'POST',headers:{'content-type':'application/json','X-iLive-Signature':signature??createHmac('sha256',secret).update(body).digest('hex')},body}),{RELAY_SECRET:secret});}
const data={bot_token:'123456:ABCDEFGHIJKLMNOPQRSTUVWX',chat_id:'-100123456789',event:'test'};
assert.equal((await request(data)).status,200);assert.equal(calls.length,1);assert(calls[0].url.includes(data.bot_token));assert.equal(calls[0].body.chat_id,data.chat_id);
assert.equal((await request({...data,bot_token:'987654:ZYXWVUTSRQPONMLKJIHGFEDC',chat_id:'12345678'})).status,200);assert.equal(calls[1].body.chat_id,'12345678');
assert.equal((await request(data,'0'.repeat(64))).status,401);assert.equal(calls.length,2);
assert.equal((await request({...data,bot_token:'../../bad'})).status,422);assert.equal(calls.length,2);
console.log('PASS: panel credential changes used; invalid HMAC and token rejected; no real Telegram messages sent.');
