<?php require __DIR__.'/config.php';$s=loadS();$apk=$s['apk']?'uploads/'.rawurlencode(basename($s['apk'])):'';?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>iLive</title><link rel="stylesheet" href="assets/style.css?v=3">
</head><body><div class="screen"><div class="panel">
<div class="badge"><?=e($s['badge'])?></div>
<div class="app-logo"><div class="play">▶</div><span></span></div>
<h1><?=e($s['title'])?></h1>
<p class="lead"><?=e($s['lead'])?></p>
<p class="sub"><?=e($s['sub'])?></p>
<div class="stats">
<div class="stat"><b><?=e($s['s1'])?></b><small><?=e($s['l1'])?></small></div>
<div class="stat"><b><?=e($s['s2'])?></b><small><?=e($s['l2'])?></small></div>
<div class="stat"><b><?=e($s['s3'])?></b><small><?=e($s['l3'])?></small></div>
</div>
<label class="age"><input id="age" type="checkbox"><i></i><span><?=e($s['confirm'])?></span></label>
<?php if($apk):?>
<a id="download" class="download disabled" href="<?=e($apk)?>" download><?=e($s['button'])?></a>
<p id="done" class="done hidden"><?=e($s['after'])?></p>
<?php else:?>
<div class="download disabled">⬇️ فایل اپلیکیشن هنوز بارگذاری نشده</div>
<?php endif;?>
</div></div><script src="assets/app.js?v=3"></script></body></html>