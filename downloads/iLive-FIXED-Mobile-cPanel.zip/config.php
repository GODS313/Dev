<?php
session_start();
define('DATA',__DIR__.'/data/settings.json');
define('UP',__DIR__.'/uploads');
function defaults(){return [
'badge'=>'🔞 مخصوص بزرگسالان بالای ۱۸ سال',
'title'=>'iLive',
'lead'=>'لایو چت زنده را با ۱۴ میلیون کاربر ایرانی شروع کنید',
'sub'=>'آشنایی، گفت‌وگوی زنده و لحظه‌های واقعی',
's1'=>'★ ۴.۸','l1'=>'رضایت کاربران',
's2'=>'۲۴/۷','l2'=>'آنلاین و زنده',
's3'=>'۱۴+ میلیون','l3'=>'کاربر ایرانی',
'confirm'=>'تأیید می‌کنم که بالای ۱۸ سال دارم',
'button'=>'⬇️ دانلود اپلیکیشن',
'after'=>'✅ دانلود شروع شد. حالا روی فایل بزنید تا نصب شود.',
'apk'=>'','user'=>'admin','hash'=>password_hash('ChangeMe123!',PASSWORD_DEFAULT)
];}
function loadS(){if(!file_exists(DATA)){saveS(defaults());return defaults();}$x=json_decode(file_get_contents(DATA),true);return is_array($x)?array_merge(defaults(),$x):defaults();}
function saveS($x){return file_put_contents(DATA,json_encode($x,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT),LOCK_EX)!==false;}
function e($x){return htmlspecialchars((string)$x,ENT_QUOTES,'UTF-8');}
function token(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function valid($x){return is_string($x)&&hash_equals($_SESSION['csrf']??'',$x);}
?>