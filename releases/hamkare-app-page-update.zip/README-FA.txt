این فایل فقط صفحه داخل اپ را اضافه می‌کند.
ZIP را داخل public_html آپلود و همان‌جا Extract کنید.
سپس باز کنید: https://adlisho.online/app/
